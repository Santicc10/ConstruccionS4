namespace Entregable3.Data;


public class InMemoryProducts
{
    
    private List<string> Codes = new List<string>{
        "F1", "F2", "F3",
        "F4", "F5", "F6",
        "F7", "F8", "F9",
        "F10"
    };

    private List<string> Names = new List<string>{
        "Manzanas", "Peras", "Guanabanas", 
        "Mangos", "Uvas", "Maracuya", 
        "Fresas", "Bananos", "Guayabas", 
        "Naranjas"
    };

    public List<Product> getProducts ()
    {
        List<Product> ListProducts = new ();
        Random random = new Random();
        for(var i = 0; i < 10; i++) {
            Product product = new Product {
                    id = i+1,
                    Code = this.Codes[i],
                    Name = this.Names[i],
                    Price = random.Next(7000)
            };
            ListProducts.Add(product);
        }

        return ListProducts;
    }
}